/* var proeba = JSON.parse( JSON.stringify(data.results[0].members) ); */


var url = "https://api.propublica.org/congress/v1/113/house/members.json";

if (document.title.includes("Senate")) {
    url= "https://api.propublica.org/congress/v1/113/senate/members.json"
}

const key = {
    method: 'GET',
    datatype: 'json',
    headers: {'X-API-Key': 'zW2i3pVYMhdHCxvI51kEY8xjJwcSEN5Kkw1EC1sW'
    }
} 
    fetch(url,key)
      .then(response => response.json())
      .then(data => {
        proeba=data.results[0].members;
        if (document.getElementById("statisticsTabla") != undefined ) {
            estadisticas(proeba)
        }
        if (document.getElementById("Data") != undefined ) {
            tableSenate(proeba)
            stateSelect(proeba)
            filters(proeba)
        }
     
        
      })

function tableSenate(table){
          document.getElementById("json").innerHTML= ``;
    
    table.forEach(element=> {
        var tableData = document.createElement("tr");
        tableData.innerHTML =  `
            <td> <a href=${element.url} target="blank" class="a"> ${element.first_name} ${element.middle_name|| ""} ${element.last_name} </a> </td>
            <td> ${element.party} </td>
            <td> ${element.state} </td>
            <td> ${element.seniority} </td>
            <td> ${element.votes_with_party_pct}%</td>`
            document.getElementById('json').appendChild(tableData);
    });
}
/* tableSenate(proeba); */


function stateSelect(){
  var states=[]
  proeba.forEach(element =>{
      states.push(element.state)
  })
  const statesArr = new Set(states);
  
  states = [...statesArr];
   for(var i=0;i<states.length;i++){
      var option;
      option=`<option value="${states[i]}">${states[i]}</option>`;
      document.getElementById("stateSelect").innerHTML +=option;
    };
  }
  /* stateSelect(); */



function filters(){
    var rep=document.getElementById("republic").checked;
    var dem=document.getElementById("democrat").checked;
    var idt=document.getElementById("independent").checked;
    var ver=rep&&dem&&idt;
    var fal=rep||dem||idt;
    fal=!fal
    if (ver==true){
        
        aplyfilter2(proeba); 
    }
    else if (fal==true){
        
       aplyfilter2(proeba);
    }
    else{
      checked();  
        
    }


function aplyfilter2(proeba){
   
   statev = document.getElementById("stateSelect").value; 
   var statefilt=[] 
   if(statev==="ALL"){ 
           
   proeba.forEach(statefilter =>{ 
            statefilt.push(statefilter);  
       })
   }

   else{ 
   proeba.forEach(statefilter =>{ 
       if (statefilter.state===statev){ 
           statefilt.push(statefilter); 
                                }
                             })
        }tableSenate(statefilt)
}

function checked(){
    var congressfilt=[]
        if(rep==true){
            proeba.forEach(partyfilter =>{ 
                if (partyfilter.party==="R"){
                    congressfilt.push(partyfilter); 
                }
               
        
            })  
        }
        if(dem==true){
            proeba.forEach(partyfilter =>{
                if (partyfilter.party==="D"){ 
                    congressfilt.push(partyfilter);
                }
               
        
            })  
        }
        if(idt==true){
            proeba.forEach(partyfilter =>{ 
                if (partyfilter.party==="ID"){ 
                    congressfilt.push(partyfilter); 
                }
        
            })
        }
aplyfilter2(congressfilt)
}}

function estadisticas() {

var votesPercentD = [];
var votesPercentR = [];
var votesPercentID = [];
var votesPercentTotal = [];
var sumaD = 0;
var sumaR = 0;
var sumaID = 0;
var sumaTotal= 0;
var i = 0;
var m = 0;

var statistics = {
    "totalproeba": proeba.length,

    "votesPer": [,],

    "numberPartyVotes": [votesPercentD, votesPercentR, votesPercentID, proeba],
    
    "partys": ["Democrats", "Republicans", "Independents", "Total"],

    "votesMostName1": tablaOrdenada(proeba),

    "democratsVotesWithParty": 96.97 + "%",
    "republicansVotesWithParty": 88.84 + "%",
    "independentsVotesWithParty": 95.18+ "%",


}
  

proeba.forEach(proeba => {
    if (proeba.party === "D") {
        votesPercentD.push(proeba.votes_with_party_pct);  
        }
    });
    /* console.log(votesPercentD) */

   for (let i = 0; i < votesPercentD.length; i++) {
       vp = votesPercentD[i];
       sumaD += vp;
   } 

/* console.log("Estos son los Democratas: "+(sumaD/votesPercentD.length).toFixed(2) + "%") */
statistics.votesPer.push(sumaD/votesPercentD.length).toFixed(2)


proeba.forEach(proeba => {
    if (proeba.party === "R") {
        votesPercentR.push(proeba.votes_with_party_pct);  
        }
    });
    /* console.log(votesPercentR) */

   for (let i = 0; i < votesPercentR.length; i++) {
       vp = votesPercentR[i];
       sumaR += vp;
   } 
/* console.log("Estos son los Republicanos: "+(sumaR/votesPercentR.length).toFixed(2) + "%") */
statistics.votesPer.push(sumaR/votesPercentR.length).toFixed(2)


proeba.forEach(proeba => {
    if (proeba.party === "ID") {
        votesPercentID.push(proeba.votes_with_party_pct);
        }
    });
    /* console.log(votesPercentID) */

    

   for (let i = 0; i < votesPercentID.length; i++) {
       vp = votesPercentID[i];
       sumaID += vp;
   } 
/* console.log("Estos son los Independientes: "+(sumaID/votesPercentID.length).toFixed(2) + "%") */
statistics.votesPer.push(sumaID/votesPercentID.length).toFixed(2)




proeba.forEach(proeba => {
    if (proeba.party) {
        votesPercentTotal.push(proeba.votes_with_party_pct);
        }
    });
    /* console.log(votesPercentTotal) */
    
   for (let i = 0; i < votesPercentTotal.length; i++) {
       vp = votesPercentTotal[i];
       sumaTotal += vp;
   } 
   statistics.votesPer.push(sumaTotal/votesPercentTotal.length)


// Members who Least and Most often Vote with their Party


let mostVotes= [];
let leastVotes = [];

let mostVotes2 = [];


let mostVotesR = [];
let leastVotesR = [];

let percent = 10;

proeba.forEach(proeba => {
    if (proeba) {
        mostVotes.push(proeba.votes_with_party_pct);  
        for (let i = 0; i < mostVotes.length; i++) {
           mostVotes.sort(function (a, b) {return b - a
            })     
           }     
    }
        
    });

    proeba.forEach(proeba => {
        if (proeba.votes_with_party_pct) {
            mostVotes2.push(proeba.votes_with_party_pct);  
        }
        });


  
       let FinalMostVotes = mostVotes.length* percent/100
       
       var x = proeba.slice(0, FinalMostVotes)

       /* console.log(mostVotes.slice(0, FinalMostVotes)) */
       /* console.log(statistics.mostVotesNameD) */     

       
   proeba.forEach(proeba => {
    if (proeba.party) {
        leastVotes.push(proeba.votes_with_party_pct);  
        }
    });      
    for (let x = 0; x < leastVotes.length; x++) {
        leastVotes.sort(function (a, b) {return a - b
        })
       }
       let FinalleastVotes = leastVotes.length* percent/100
 /*       console.log(statistics.leastVotesNameD)
       console.log(leastVotes.slice(0, FinalleastVotes)) */






   proeba.forEach(proeba => {
    if (proeba.party === "R") {
        mostVotesR.push(proeba.votes_with_party_pct);  
        }
    });
    for (let x = 0; x < mostVotesR.length; x++) {
        mostVotesR.sort(function (a, b) {return b - a
        })       
       } 
       let FinalMostVotesR = mostVotesR.length* percent/100
   /*     console.log(statistics.mostVotesNameR)
       console.log(mostVotesR.slice(0, FinalMostVotesR)) */
       
 
   
       
   proeba.forEach(proeba => {
    if (proeba.party === "R") {
        leastVotesR.push(proeba.votes_with_party_pct);  
        }
    });      
    for (let x = 0; x < leastVotesR.length; x++) {
        leastVotesR.sort(function (a, b) {return a - b
        })
       } 
       let FinalLeastVotesR = leastVotesR.length* percent/100
/*        console.log(statistics.leastVotesNameR)
       console.log(leastVotesR.slice(0, FinalLeastVotesR))
        */



// Tables 
 
    function tableC(table) {
        document.getElementById("tablaSenate").innerHTML = ``;
          table.forEach(senadores => {
            let tr = document.createElement("tr");
            tr.innerHTML =
            `
              <td> ${statistics.partys[i++]} </td>
              <td> ${statistics.numberPartyVotes[m++].length} </td>
              <td> ${(statistics.votesPer[i].toFixed(2)||"0")} % </td>
              
            `
              document.getElementById('tablaSenate').appendChild(tr);
          });
      }
      tableC(statistics.partys)

/* tableC3(tablaOrdenada(proeba))
      function tableC3(table) {
        document.getElementById("tablaLeastLoyal").innerHTML = ``;
          console.log(table)
        table.forEach(senadores => {
            let tr = document.createElement("tr");
            tr.innerHTML =
            `
              <td><a href="${senadores.url}"> ${senadores.first_name} ${senadores.middle_name || ""} ${senadores.last_name}</a></td>
              <td> ${Math.round((senadores.total_votes - senadores.missed_votes) * senadores.votes_with_party_pct / 100)}</td>
              <td> ${leastVotes[i++]} % </td>
              <td> ${tablaOrdenada(proeba)} </td>
            `
              document.getElementById('tablaLeastLoyal').appendChild(tr);
          });
      }
      tableC3(statistics.votesMostName1) */
     
     tabletbody(tablaOrdenada(proeba,2), "tablaLeastLoyal")
      function tabletbody(tnpc,idselect){
  
        document.getElementById(`${idselect}`).innerHTML=``;
       
        tnpc.forEach(element => {
        
        var tr2=document.createElement("tr");
        tr2.innerHTML=`<td><a href="${element.url}">${element.first_name} ${element.middle_name ||''} ${element.last_name}</a></td>
        <td>${Math.round((element.total_votes - element.missed_votes) * element.votes_with_party_pct / 100)}</td>
        <td>${element.votes_with_party_pct}%</td>`
       
        document.getElementById(`tablaLeastLoyal`).appendChild(tr2);
    
    });}



    tabletbody2(tablaOrdenada(proeba,1), "tablaMostLoyal")
      function tabletbody2(tnpc,idselect){

        document.getElementById(`${idselect}`).innerHTML=``;
       
        tnpc.forEach(element => {
        
        var tr2=document.createElement("tr");
        tr2.innerHTML=`<td><a href="${element.url}">${element.first_name} ${element.middle_name ||''} ${element.last_name}</a></td>
        <td>${Math.round((element.total_votes - element.missed_votes) * element.votes_with_party_pct / 100)}</td>
        <td>${element.votes_with_party_pct}%</td>`
       
        document.getElementById(`${idselect}`).appendChild(tr2);
    });}


    tabletbody2(tablaOrdenada(proeba,3), "tablaMostLoyal")
    function tabletbody2(tnpc,idselect){

      document.getElementById(`${idselect}`).innerHTML=``;
     
      tnpc.forEach(element => {
      
      var tr2=document.createElement("tr");
      tr2.innerHTML=`<td><a href="${element.url}">${element.first_name} ${element.middle_name ||''} ${element.last_name}</a></td>
      <td>${element.missed_votes}</td>
      <td>${element.missed_votes_pct}%</td>`
     
      document.getElementById(`${idselect}`).appendChild(tr2);
  
  });}

  tabletbody2(tablaOrdenada(proeba,4), "tablaLeastLoyal")
  function tabletbody2(tnpc,idselect){

    document.getElementById(`${idselect}`).innerHTML=``;
   
    tnpc.forEach(element => {
    
    var tr2=document.createElement("tr");
    tr2.innerHTML=`<td><a href="${element.url}">${element.first_name} ${element.middle_name ||''} ${element.last_name}</a></td>
    <td>${element.missed_votes}</td>
    <td>${element.missed_votes_pct}%</td>`
   
    document.getElementById(`${idselect}`).appendChild(tr2);

});}


    

function tablaOrdenada(cualquiera,programa) {

      var votesMostName12 = [];
      var porcentaje = (cualquiera.length)*0.1

      console.log(porcentaje)
      cualquiera.forEach(member => {
          votesMostName12.push(member);
      });
      if (programa == 2) {
        var porcentaje2 = votesMostName12.sort((a, b)=> a.votes_with_party_pct - b.votes_with_party_pct).slice(0,porcentaje);
      }
      if (programa == 1) {
        var porcentaje2 = votesMostName12.sort((a, b)=> b.votes_with_party_pct - a.votes_with_party_pct).slice(0,porcentaje);
      }
      if (programa == 3) {
        var porcentaje2 = votesMostName12.sort((a, b)=> a.missed_votes_pct - b.missed_votes_pct).slice(0,porcentaje);
      }
      if (programa == 4) {
        var porcentaje2 = votesMostName12.sort((a, b)=> b.missed_votes_pct - a.missed_votes_pct).slice(0,porcentaje);
      }
      return porcentaje2
    }
}